document.getElementById('safety-icon-btn').addEventListener('click', function() {
    window.location.href = 'safety.html';  // Redirect to the safety mode page
});

function sendSOSMessage() {
    alert("SOS Message Sent!");
}
